
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Zap, Leaf, TrendingDown, DollarSign, ArrowRight, 
  CheckCircle, AlertCircle, BarChart3, Award,
  ChevronRight, Download, Share2, Lightbulb
} from 'lucide-react';

const AnalysisResults = () => {
  const { billId } = useParams();
  const [loading, setLoading] = useState(true);
  const [results, setResults] = useState(null);

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setResults({
        summary: {
          total_bill: 847.50,
          kwh_used: 6250,
          cost_per_kwh: 0.136,
          efficiency_score: 68,
          industry_comparison: 'average',
          potential_savings: 2542.50
        },
        metrics: {
          kwh_per_sqft: 4.2,
          benchmark_avg: 3.5,
          potential_waste_percent: 16.7,
          wasted_kwh_monthly: 1042,
          wasted_cost_monthly: 141.67,
          wasted_cost_annual: 1700.00,
          co2_emissions_monthly_kg: 2500,
          trees_needed: 50
        },
        recommendations: [
          {
            title: 'Upgrade to LED Lighting',
            annual_savings: 892.50,
            implementation_cost: 500,
            roi_years: 0.6,
            priority: 'high',
            difficulty: 'easy',
            category: 'lighting'
          },
          {
            title: 'Install Smart Thermostat',
            annual_savings: 595.00,
            implementation_cost: 250,
            roi_years: 0.4,
            priority: 'high',
            difficulty: 'easy',
            category: 'hvac'
          },
          {
            title: 'HVAC System Tune-up',
            annual_savings: 714.00,
            implementation_cost: 300,
            roi_years: 0.4,
            priority: 'high',
            difficulty: 'easy',
            category: 'hvac'
          }
        ]
      });
      setLoading(false);
    }, 1500);
  }, [billId]);

  if (loading) {
    return (
      <div className="dashboard" style={{display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '100vh'}}>
        <div style={{textAlign: 'center'}}>
          <div className="loading-spinner"></div>
          <h3 style={{marginTop: '1.5rem'}}>Loading your analysis...</h3>
        </div>
      </div>
    );
  }

  const { summary, metrics, recommendations } = results;

  return (
    <div className="dashboard">
      <div className="bg-animation"></div>

      {/* Header */}
      <nav className="navbar">
        <Link to="/" className="logo">
          <div className="logo-icon">
            <Leaf size={24} color="white" />
          </div>
          EcoSave AI
        </Link>
        <div style={{display: 'flex', gap: '1rem'}}>
          <button style={{
            background: 'transparent',
            border: '1px solid rgba(16, 185, 129, 0.3)',
            color: '#10B981',
            padding: '0.5rem 1rem',
            borderRadius: '8px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem'
          }}>
            <Share2 size={18} />
            Share
          </button>
          <button style={{
            background: 'linear-gradient(135deg, #10B981 0%, #14B8A6 100%)',
            border: 'none',
            color: 'white',
            padding: '0.5rem 1rem',
            borderRadius: '8px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem'
          }}>
            <Download size={18} />
            Download Report
          </button>
        </div>
      </nav>

      <div className="results-container">
        {/* Score Card */}
        <div className="result-card" style={{textAlign: 'center'}}>
          <h2 style={{marginBottom: '0.5rem'}}>Your Energy Efficiency Score</h2>
          <p style={{color: '#94A3B8', marginBottom: '2rem'}}>
            Based on your bill analysis compared to similar businesses
          </p>

          <div style={{
            width: '200px',
            height: '200px',
            margin: '0 auto 2rem',
            position: 'relative'
          }}>
            <svg viewBox="0 0 100 100" style={{transform: 'rotate(-90deg)'}}>
              <circle
                cx="50"
                cy="50"
                r="45"
                fill="none"
                stroke="rgba(16, 185, 129, 0.1)"
                strokeWidth="8"
              />
              <circle
                cx="50"
                cy="50"
                r="45"
                fill="none"
                stroke="url(#gradient)"
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={`${summary.efficiency_score * 2.83} 283`}
                style={{transition: 'stroke-dasharray 1s ease'}}
              />
              <defs>
                <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#10B981" />
                  <stop offset="100%" stopColor="#14B8A6" />
                </linearGradient>
              </defs>
            </svg>
            <div style={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              textAlign: 'center'
            }}>
              <div style={{fontSize: '3rem', fontWeight: 700, color: '#10B981'}}>
                {summary.efficiency_score}
              </div>
              <div style={{fontSize: '0.875rem', color: '#94A3B8'}}>out of 100</div>
            </div>
          </div>

          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '0.5rem',
            background: summary.industry_comparison === 'average' ? 'rgba(245, 158, 11, 0.1)' : 'rgba(16, 185, 129, 0.1)',
            color: summary.industry_comparison === 'average' ? '#F59E0B' : '#10B981',
            padding: '0.5rem 1rem',
            borderRadius: '50px',
            fontSize: '0.875rem',
            fontWeight: 600
          }}>
            <AlertCircle size={16} />
            {summary.industry_comparison === 'average' ? 'Average for your industry' : 'Above average'}
          </div>
        </div>

        {/* Key Metrics Grid */}
        <div className="dashboard-grid">
          <div className="metric-card">
            <div className="metric-header">
              <DollarSign size={18} />
              Monthly Energy Cost
            </div>
            <div className="metric-value">${summary.total_bill.toFixed(2)}</div>
            <div className="metric-change negative">
              <TrendingDown size={16} />
              ${metrics.wasted_cost_monthly.toFixed(0)} potential waste
            </div>
          </div>

          <div className="metric-card">
            <div className="metric-header">
              <Zap size={18} />
              Energy Usage
            </div>
            <div className="metric-value">{summary.kwh_used.toLocaleString()} <span style={{fontSize: '1rem', color: '#94A3B8'}}>kWh</span></div>
            <div className="metric-change">
              {metrics.kwh_per_sqft} kWh/sq ft
            </div>
          </div>

          <div className="metric-card">
            <div className="metric-header">
              <Leaf size={18} />
              CO₂ Emissions
            </div>
            <div className="metric-value">{metrics.co2_emissions_monthly_kg.toLocaleString()} <span style={{fontSize: '1rem', color: '#94A3B8'}}>kg</span></div>
            <div className="metric-change">
              Like {metrics.trees_needed} trees needed to offset
            </div>
          </div>

          <div className="metric-card" style={{border: '2px solid #10B981'}}>
            <div className="metric-header" style={{color: '#10B981'}}>
              <Award size={18} />
              Potential Annual Savings
            </div>
            <div className="metric-value" style={{color: '#10B981'}}>${summary.potential_savings.toLocaleString()}</div>
            <div className="metric-change positive">
              <TrendingDown size={16} />
              30% reduction possible
            </div>
          </div>
        </div>

        {/* Comparison Chart */}
        <div className="result-card">
          <h3 style={{marginBottom: '1.5rem'}}>How You Compare</h3>

          <div style={{marginBottom: '1.5rem'}}>
            <div style={{display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem'}}>
              <span style={{color: '#94A3B8'}}>Your Usage</span>
              <span style={{fontWeight: 600}}>{metrics.kwh_per_sqft} kWh/sq ft</span>
            </div>
            <div className="progress-bar">
              <div className="progress-fill" style={{width: '80%', background: '#EF4444'}}></div>
            </div>
          </div>

          <div style={{marginBottom: '1.5rem'}}>
            <div style={{display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem'}}>
              <span style={{color: '#94A3B8'}}>Industry Average</span>
              <span style={{fontWeight: 600}}>{metrics.benchmark_avg} kWh/sq ft</span>
            </div>
            <div className="progress-bar">
              <div className="progress-fill" style={{width: '65%', background: '#F59E0B'}}></div>
            </div>
          </div>

          <div>
            <div style={{display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem'}}>
              <span style={{color: '#94A3B8'}}>Best in Class</span>
              <span style={{fontWeight: 600}}>{(metrics.benchmark_avg * 0.7).toFixed(1)} kWh/sq ft</span>
            </div>
            <div className="progress-bar">
              <div className="progress-fill" style={{width: '45%'}}></div>
            </div>
          </div>

          <div style={{
            marginTop: '1.5rem',
            padding: '1rem',
            background: 'rgba(16, 185, 129, 0.05)',
            borderRadius: '12px',
            borderLeft: '4px solid #10B981'
          }}>
            <p style={{margin: 0, fontSize: '0.95rem'}}>
              <strong>Insight:</strong> You are using <strong>{metrics.potential_waste_percent}%</strong> more energy than efficient businesses in your category. 
              This equals <strong>${metrics.wasted_cost_annual.toLocaleString()}</strong> in annual waste.
            </p>
          </div>
        </div>

        {/* Top Recommendations Preview */}
        <div className="result-card">
          <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem'}}>
            <h3 style={{margin: 0}}>Top Recommendations</h3>
            <Link 
              to={`/recommendations/${billId}`}
              style={{
                color: '#10B981',
                textDecoration: 'none',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                fontWeight: 600
              }}
            >
              View All
              <ChevronRight size={18} />
            </Link>
          </div>

          <div className="recommendation-list">
            {recommendations.slice(0, 3).map((rec, idx) => (
              <div key={idx} className="recommendation-item">
                <div style={{display: 'flex', alignItems: 'center', gap: '1rem', flex: 1}}>
                  <div style={{
                    width: '48px',
                    height: '48px',
                    background: 'rgba(16, 185, 129, 0.1)',
                    borderRadius: '12px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#10B981'
                  }}>
                    <Lightbulb size={24} />
                  </div>
                  <div style={{flex: 1}}>
                    <h4 style={{margin: '0 0 0.25rem 0'}}>{rec.title}</h4>
                    <p style={{margin: 0, color: '#94A3B8', fontSize: '0.875rem'}}>
                      ROI: {rec.roi_years} years • {rec.difficulty} implementation
                    </p>
                  </div>
                </div>
                <div style={{textAlign: 'right'}}>
                  <div style={{fontSize: '1.25rem', fontWeight: 700, color: '#10B981'}}>
                    ${rec.annual_savings.toLocaleString()}
                  </div>
                  <div style={{fontSize: '0.75rem', color: '#94A3B8'}}>/year saved</div>
                </div>
              </div>
            ))}
          </div>

          <Link 
            to={`/recommendations/${billId}`}
            className="cta-button"
            style={{
              display: 'flex',
              justifyContent: 'center',
              marginTop: '1.5rem',
              width: '100%'
            }}
          >
            See Full Action Plan
            <ArrowRight size={20} />
          </Link>
        </div>

        {/* Environmental Impact */}
        <div className="result-card" style={{
          background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.1) 0%, rgba(20, 184, 166, 0.1) 100%)',
          border: '1px solid rgba(16, 185, 129, 0.3)'
        }}>
          <div style={{display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem'}}>
            <div style={{
              width: '56px',
              height: '56px',
              background: 'linear-gradient(135deg, #10B981 0%, #14B8A6 100%)',
              borderRadius: '16px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <Leaf size={28} color="white" />
            </div>
            <div>
              <h3 style={{margin: '0 0 0.25rem 0'}}>Your Environmental Impact</h3>
              <p style={{margin: 0, color: '#94A3B8'}}>By implementing our recommendations, you could:</p>
            </div>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '1rem',
            marginTop: '1.5rem'
          }}>
            <div style={{
              background: 'rgba(15, 23, 42, 0.8)',
              padding: '1.5rem',
              borderRadius: '12px',
              textAlign: 'center'
            }}>
              <div style={{fontSize: '2rem', fontWeight: 700, color: '#10B981', marginBottom: '0.5rem'}}>
                {(metrics.co2_emissions_monthly_kg * 0.3 * 12 / 1000).toFixed(1)}
              </div>
              <div style={{color: '#94A3B8', fontSize: '0.875rem'}}>tons CO₂ saved annually</div>
            </div>

            <div style={{
              background: 'rgba(15, 23, 42, 0.8)',
              padding: '1.5rem',
              borderRadius: '12px',
              textAlign: 'center'
            }}>
              <div style={{fontSize: '2rem', fontWeight: 700, color: '#10B981', marginBottom: '0.5rem'}}>
                {Math.round(metrics.trees_needed * 0.3)}
              </div>
              <div style={{color: '#94A3B8', fontSize: '0.875rem'}}>equivalent trees planted</div>
            </div>

            <div style={{
              background: 'rgba(15, 23, 42, 0.8)',
              padding: '1.5rem',
              borderRadius: '12px',
              textAlign: 'center'
            }}>
              <div style={{fontSize: '2rem', fontWeight: 700, color: '#10B981', marginBottom: '0.5rem'}}>
                {(summary.kwh_used * 0.3 / 1000).toFixed(1)}k
              </div>
              <div style={{color: '#94A3B8', fontSize: '0.875rem'}}>kWh saved annually</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalysisResults;
