
import React, { useState } from 'react';
import { 
  Upload, Zap, Leaf, TrendingDown, DollarSign, 
  BarChart3, CheckCircle, ArrowRight, Sun, Wind,
  Menu, X, ChevronRight, Star, Users, Award,
  Shield, Clock, Sparkles
} from 'lucide-react';
import { Link } from 'react-router-dom';

const LandingPage = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="landing-page">
      <div className="bg-animation"></div>

      {/* Navigation */}
      <nav className="navbar">
        <Link to="/" className="logo">
          <div className="logo-icon">
            <Leaf size={24} color="white" />
          </div>
          EcoSave AI
        </Link>

        <ul className="nav-links">
          <li><a href="#features">Features</a></li>
          <li><a href="#how-it-works">How It Works</a></li>
          <li><a href="#pricing">Pricing</a></li>
          <li><Link to="/dashboard" className="cta-button">
            Start Free Analysis
          </Link></li>
        </ul>
      </nav>

      {/* Hero Section */}
      <section className="hero">
        <div className="hero-content">
          <div className="hero-badge animate-fade-in">
            <Sparkles size={16} />
            AI-Powered Energy Intelligence
          </div>

          <h1 className="animate-fade-in delay-1">
            Cut Your Energy Bills by <span style={{color: '#10B981'}}>30%</span> with AI
          </h1>

          <p className="animate-fade-in delay-2">
            Upload your electricity bill. Our AI analyzes your usage patterns and 
            delivers personalized recommendations to save money and reduce your carbon footprint.
          </p>

          <div className="animate-fade-in delay-3">
            <Link to="/dashboard" className="cta-button" style={{fontSize: '1.1rem', padding: '1rem 2rem'}}>
              Analyze My Bill Free
              <ArrowRight size={20} />
            </Link>
            <p style={{marginTop: '1rem', fontSize: '0.875rem', color: '#94A3B8'}}>
              ✓ No credit card required • ✓ Takes 2 minutes • ✓ Instant results
            </p>
          </div>

          <div className="hero-stats animate-fade-in delay-3">
            <div className="stat-item">
              <span className="stat-number">$2.4M+</span>
              <span className="stat-label">Saved for Businesses</span>
            </div>
            <div className="stat-item">
              <span className="stat-number">1,200+</span>
              <span className="stat-label">Bills Analyzed</span>
            </div>
            <div className="stat-item">
              <span className="stat-number">4.9/5</span>
              <span className="stat-label">Customer Rating</span>
            </div>
          </div>
        </div>

        {/* Hero Visual */}
        <div className="hero-visual" style={{
          position: 'absolute',
          right: '5%',
          top: '50%',
          transform: 'translateY(-50%)',
          width: '500px',
          height: '500px',
          opacity: 0.8
        }}>
          <div style={{
            position: 'relative',
            width: '100%',
            height: '100%'
          }}>
            {/* Animated Circles */}
            <div style={{
              position: 'absolute',
              width: '300px',
              height: '300px',
              border: '2px solid rgba(16, 185, 129, 0.2)',
              borderRadius: '50%',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              animation: 'pulse 3s infinite'
            }}></div>
            <div style={{
              position: 'absolute',
              width: '400px',
              height: '400px',
              border: '2px solid rgba(16, 185, 129, 0.1)',
              borderRadius: '50%',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              animation: 'pulse 3s infinite 1s'
            }}></div>

            {/* Center Icon */}
            <div style={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              width: '120px',
              height: '120px',
              background: 'linear-gradient(135deg, #10B981 0%, #14B8A6 100%)',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 0 40px rgba(16, 185, 129, 0.4)'
            }}>
              <Zap size={48} color="white" />
            </div>

            {/* Floating Elements */}
            <div style={{
              position: 'absolute',
              top: '20%',
              left: '10%',
              background: 'rgba(30, 41, 59, 0.9)',
              padding: '1rem',
              borderRadius: '12px',
              border: '1px solid rgba(16, 185, 129, 0.3)',
              animation: 'float 4s ease-in-out infinite'
            }}>
              <div style={{display: 'flex', alignItems: 'center', gap: '0.5rem'}}>
                <TrendingDown size={20} color="#10B981" />
                <span style={{color: '#10B981', fontWeight: 600}}>-32%</span>
              </div>
              <span style={{fontSize: '0.75rem', color: '#94A3B8'}}>Energy Cost</span>
            </div>

            <div style={{
              position: 'absolute',
              bottom: '20%',
              right: '10%',
              background: 'rgba(30, 41, 59, 0.9)',
              padding: '1rem',
              borderRadius: '12px',
              border: '1px solid rgba(16, 185, 129, 0.3)',
              animation: 'float 4s ease-in-out infinite 2s'
            }}>
              <div style={{display: 'flex', alignItems: 'center', gap: '0.5rem'}}>
                <Leaf size={20} color="#10B981" />
                <span style={{color: '#10B981', fontWeight: 600}}>-450kg</span>
              </div>
              <span style={{fontSize: '0.75rem', color: '#94A3B8'}}>CO₂ Saved</span>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <section style={{
        padding: '3rem 5%',
        textAlign: 'center',
        borderTop: '1px solid rgba(16, 185, 129, 0.1)',
        borderBottom: '1px solid rgba(16, 185, 129, 0.1)'
      }}>
        <p style={{color: '#94A3B8', marginBottom: '1.5rem', fontSize: '0.875rem'}}>
          Trusted by small businesses across industries
        </p>
        <div style={{
          display: 'flex',
          justifyContent: 'center',
          gap: '3rem',
          flexWrap: 'wrap',
          opacity: 0.6
        }}>
          {['Restaurants', 'Retail Stores', 'Offices', 'Warehouses', 'Hotels'].map((business) => (
            <span key={business} style={{
              color: '#64748B',
              fontWeight: 600,
              fontSize: '1.1rem'
            }}>
              {business}
            </span>
          ))}
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="features">
        <div className="section-title">
          <h2>How EcoSave AI Works</h2>
          <p>Three simple steps to start saving money and the planet</p>
        </div>

        <div className="features-grid">
          <div className="feature-card">
            <div className="feature-icon">
              <Upload size={24} />
            </div>
            <h3>1. Upload Your Bill</h3>
            <p>Simply upload your electricity bill (PDF or photo). Our AI reads and extracts all relevant data in seconds.</p>
          </div>

          <div className="feature-card">
            <div className="feature-icon">
              <BarChart3 size={24} />
            </div>
            <h3>2. AI Analysis</h3>
            <p>Our algorithms compare your usage against industry benchmarks and identify waste patterns specific to your business.</p>
          </div>

          <div className="feature-card">
            <div className="feature-icon">
              <CheckCircle size={24} />
            </div>
            <h3>3. Get Recommendations</h3>
            <p>Receive a personalized action plan with specific recommendations, ROI calculations, and implementation steps.</p>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section style={{
        padding: '6rem 5%',
        background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.05) 0%, transparent 100%)'
      }}>
        <div style={{
          maxWidth: '1200px',
          margin: '0 auto',
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: '4rem',
          alignItems: 'center'
        }}>
          <div>
            <h2 style={{fontSize: '2.5rem', marginBottom: '1.5rem'}}>
              Why Businesses Choose EcoSave AI
            </h2>

            <div style={{display: 'flex', flexDirection: 'column', gap: '1.5rem'}}>
              {[
                {icon: DollarSign, title: 'Average 30% Savings', desc: 'Our users save an average of $3,200 annually on energy costs.'},
                {icon: Clock, title: '5-Minute Setup', desc: 'No hardware installation. No site visits. Just upload your bill.'},
                {icon: Shield, title: 'Bank-Level Security', desc: 'Your data is encrypted and never shared with third parties.'},
                {icon: Sun, title: 'Sustainability Impact', desc: 'Track your CO₂ reduction and contribute to a greener planet.'}
              ].map((item, idx) => (
                <div key={idx} style={{
                  display: 'flex',
                  gap: '1rem',
                  alignItems: 'flex-start'
                }}>
                  <div style={{
                    width: '48px',
                    height: '48px',
                    background: 'rgba(16, 185, 129, 0.1)',
                    borderRadius: '12px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#10B981',
                    flexShrink: 0
                  }}>
                    <item.icon size={24} />
                  </div>
                  <div>
                    <h4 style={{marginBottom: '0.25rem'}}>{item.title}</h4>
                    <p style={{color: '#94A3B8', fontSize: '0.95rem'}}>{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div style={{
            background: 'rgba(30, 41, 59, 0.8)',
            borderRadius: '20px',
            padding: '2rem',
            border: '1px solid rgba(16, 185, 129, 0.2)'
          }}>
            <h3 style={{marginBottom: '1.5rem', textAlign: 'center'}}>Sample Analysis Results</h3>

            <div style={{marginBottom: '1.5rem'}}>
              <div style={{display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem'}}>
                <span style={{color: '#94A3B8'}}>Current Monthly Cost</span>
                <span style={{fontWeight: 600}}>$840</span>
              </div>
              <div className="progress-bar">
                <div className="progress-fill" style={{width: '100%', background: '#EF4444'}}></div>
              </div>
            </div>

            <div style={{marginBottom: '1.5rem'}}>
              <div style={{display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem'}}>
                <span style={{color: '#94A3B8'}}>Potential with EcoSave</span>
                <span style={{fontWeight: 600, color: '#10B981'}}>$588</span>
              </div>
              <div className="progress-bar">
                <div className="progress-fill" style={{width: '70%'}}></div>
              </div>
            </div>

            <div style={{
              background: 'rgba(16, 185, 129, 0.1)',
              borderRadius: '12px',
              padding: '1.5rem',
              textAlign: 'center',
              border: '1px solid rgba(16, 185, 129, 0.3)'
            }}>
              <div style={{fontSize: '2rem', fontWeight: 700, color: '#10B981', marginBottom: '0.5rem'}}>
                $3,024
              </div>
              <div style={{color: '#94A3B8'}}>Estimated Annual Savings</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section style={{
        padding: '6rem 5%',
        textAlign: 'center'
      }}>
        <div style={{
          maxWidth: '800px',
          margin: '0 auto',
          background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.1) 0%, rgba(20, 184, 166, 0.1) 100%)',
          borderRadius: '24px',
          padding: '4rem 2rem',
          border: '1px solid rgba(16, 185, 129, 0.3)'
        }}>
          <h2 style={{fontSize: '2.5rem', marginBottom: '1rem'}}>
            Ready to Start Saving?
          </h2>
          <p style={{color: '#94A3B8', fontSize: '1.125rem', marginBottom: '2rem'}}>
            Join 1,200+ businesses that have reduced their energy costs with EcoSave AI.
            First analysis is completely free.
          </p>
          <Link to="/dashboard" className="cta-button" style={{fontSize: '1.25rem', padding: '1rem 2.5rem'}}>
            Get Your Free Analysis
            <ArrowRight size={24} />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer style={{
        padding: '3rem 5%',
        borderTop: '1px solid rgba(16, 185, 129, 0.1)',
        textAlign: 'center',
        color: '#64748B'
      }}>
        <div style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          gap: '0.5rem',
          marginBottom: '1rem'
        }}>
          <Leaf size={20} color="#10B981" />
          <span style={{fontWeight: 600, color: '#10B981'}}>EcoSave AI</span>
        </div>
        <p style={{fontSize: '0.875rem'}}>
          © 2025 EcoSave AI. Making businesses greener, one bill at a time.
        </p>
      </footer>

      <style>{`
        @keyframes pulse {
          0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 0.5; }
          50% { transform: translate(-50%, -50%) scale(1.1); opacity: 0.3; }
        }
        @keyframes float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-20px); }
        }
      `}</style>
    </div>
  );
};

export default LandingPage;
