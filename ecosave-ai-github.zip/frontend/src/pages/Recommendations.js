
import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  ArrowLeft, Lightbulb, DollarSign, Clock, CheckCircle, 
  ChevronDown, ChevronUp, Zap, Download, Calendar, 
  TrendingUp, AlertCircle, Award
} from 'lucide-react';

const Recommendations = () => {
  const { billId } = useParams();
  const [expandedRec, setExpandedRec] = useState(0);
  const [showImplementationPlan, setShowImplementationPlan] = useState(false);

  const recommendations = [
    {
      id: 1,
      title: 'Upgrade to LED Lighting',
      description: 'Replace all incandescent and fluorescent bulbs with LED alternatives. LEDs use 75% less energy and last 25 times longer than traditional bulbs.',
      implementation: 'Start with high-usage areas like main lighting, then move to secondary spaces. Most businesses see ROI within 6-12 months.',
      difficulty: 'easy',
      cost: 500,
      annual_savings: 892.50,
      roi_years: 0.6,
      priority: 'high',
      category: 'lighting',
      steps: [
        'Audit current lighting fixtures and bulb types',
        'Calculate number of LEDs needed',
        'Purchase ENERGY STAR certified LEDs',
        'Schedule installation during off-hours',
        'Dispose of old bulbs responsibly'
      ],
      suppliers: ['Home Depot', 'Lowe's', 'Amazon Business'],
      co2_reduction: 450
    },
    {
      id: 2,
      title: 'Install Smart Thermostat',
      description: 'Smart thermostats learn your schedule and automatically adjust temperature when business is closed, reducing waste by 10-15%.',
      implementation: 'Install programmable thermostat and set schedules for business hours. Most units pay for themselves in 4-6 months.',
      difficulty: 'easy',
      cost: 250,
      annual_savings: 595.00,
      roi_years: 0.4,
      priority: 'high',
      category: 'hvac',
      steps: [
        'Choose compatible smart thermostat (Nest, Ecobee, Honeywell)',
        'Turn off power to HVAC system',
        'Remove old thermostat and label wires',
        'Install new unit following manufacturer instructions',
        'Set schedule: business hours vs. closed hours',
        'Enable auto-learning features'
      ],
      suppliers: ['Nest', 'Ecobee', 'Honeywell Home'],
      co2_reduction: 320
    },
    {
      id: 3,
      title: 'HVAC System Tune-up',
      description: 'Regular maintenance improves HVAC efficiency by up to 15%. Clean filters, check ducts for leaks, and optimize settings.',
      implementation: 'Schedule quarterly maintenance. Replace filters monthly. Check for duct leaks and seal them.',
      difficulty: 'easy',
      cost: 300,
      annual_savings: 714.00,
      roi_years: 0.4,
      priority: 'high',
      category: 'hvac',
      steps: [
        'Schedule professional HVAC inspection',
        'Replace air filters (monthly)',
        'Clean condenser coils',
        'Check and seal duct leaks',
        'Calibrate thermostat settings',
        'Install programmable schedules'
      ],
      suppliers: ['Local HVAC contractors', 'ServiceTitan'],
      co2_reduction: 380
    },
    {
      id: 4,
      title: 'Smart Power Strips',
      description: 'Eliminate phantom loads from equipment on standby. Smart power strips automatically cut power when devices are not in use.',
      implementation: 'Install on workstations, kitchen equipment, and areas with multiple devices.',
      difficulty: 'easy',
      cost: 150,
      annual_savings: 297.50,
      roi_years: 0.5,
      priority: 'medium',
      category: 'equipment',
      steps: [
        'Identify equipment with standby power',
        'Purchase advanced power strips with auto-switching',
        'Plug master device (computer) into control outlet',
        'Plug peripherals into switched outlets',
        'Test auto-shutoff functionality'
      ],
      suppliers: ['Amazon', 'Best Buy', 'Staples'],
      co2_reduction: 160
    },
    {
      id: 5,
      title: 'Motion Sensor Lighting',
      description: 'Install occupancy sensors in storage rooms, bathrooms, and low-traffic areas to automatically turn off lights when unoccupied.',
      implementation: 'Install sensors in areas with intermittent use. Combine with LED upgrade for maximum savings.',
      difficulty: 'easy',
      cost: 400,
      annual_savings: 476.00,
      roi_years: 0.8,
      priority: 'medium',
      category: 'lighting',
      steps: [
        'Identify low-traffic areas (storage, restrooms, back rooms)',
        'Choose appropriate sensor type (PIR or ultrasonic)',
        'Turn off power to existing switches',
        'Install sensors according to manufacturer guide',
        'Adjust sensitivity and timeout settings',
        'Test coverage and fine-tune'
      ],
      suppliers: ['Lutron', 'Leviton', 'Honeywell'],
      co2_reduction: 240
    }
  ];

  const totalSavings = recommendations.reduce((acc, rec) => acc + rec.annual_savings, 0);
  const totalCost = recommendations.reduce((acc, rec) => acc + rec.cost, 0);
  const totalCO2 = recommendations.reduce((acc, rec) => acc + rec.co2_reduction, 0);

  const getDifficultyColor = (diff) => {
    switch(diff) {
      case 'easy': return '#10B981';
      case 'medium': return '#F59E0B';
      case 'hard': return '#EF4444';
      default: return '#94A3B8';
    }
  };

  return (
    <div className="dashboard">
      <div className="bg-animation"></div>

      {/* Header */}
      <nav className="navbar">
        <Link to={`/results/${billId}`} style={{textDecoration: 'none', color: 'inherit', display: 'flex', alignItems: 'center', gap: '0.5rem'}}>
          <ArrowLeft size={20} />
          Back to Results
        </Link>
        <div style={{display: 'flex', gap: '1rem'}}>
          <button 
            onClick={() => setShowImplementationPlan(true)}
            style={{
              background: 'linear-gradient(135deg, #10B981 0%, #14B8A6 100%)',
              border: 'none',
              color: 'white',
              padding: '0.5rem 1rem',
              borderRadius: '8px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}
          >
            <Calendar size={18} />
            Implementation Plan
          </button>
        </div>
      </nav>

      <div className="results-container">
        {/* Summary Card */}
        <div className="result-card" style={{textAlign: 'center'}}>
          <h2 style={{marginBottom: '0.5rem'}}>Your Personalized Action Plan</h2>
          <p style={{color: '#94A3B8', marginBottom: '2rem'}}>
            Based on your bill analysis, here are the top 5 recommendations ranked by ROI
          </p>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '1.5rem',
            marginTop: '2rem'
          }}>
            <div style={{
              background: 'rgba(16, 185, 129, 0.1)',
              padding: '1.5rem',
              borderRadius: '16px',
              border: '1px solid rgba(16, 185, 129, 0.3)'
            }}>
              <DollarSign size={32} color="#10B981" style={{marginBottom: '0.5rem'}} />
              <div style={{fontSize: '2rem', fontWeight: 700, color: '#10B981'}}>
                ${totalSavings.toLocaleString()}
              </div>
              <div style={{color: '#94A3B8', fontSize: '0.875rem'}}>Annual Savings</div>
            </div>

            <div style={{
              background: 'rgba(16, 185, 129, 0.1)',
              padding: '1.5rem',
              borderRadius: '16px',
              border: '1px solid rgba(16, 185, 129, 0.3)'
            }}>
              <Clock size={32} color="#10B981" style={{marginBottom: '0.5rem'}} />
              <div style={{fontSize: '2rem', fontWeight: 700, color: '#10B981'}}>
                {(totalCost / totalSavings).toFixed(1)}
              </div>
              <div style={{color: '#94A3B8', fontSize: '0.875rem'}}>Years to ROI</div>
            </div>

            <div style={{
              background: 'rgba(16, 185, 129, 0.1)',
              padding: '1.5rem',
              borderRadius: '16px',
              border: '1px solid rgba(16, 185, 129, 0.3)'
            }}>
              <Award size={32} color="#10B981" style={{marginBottom: '0.5rem'}} />
              <div style={{fontSize: '2rem', fontWeight: 700, color: '#10B981'}}>
                ${totalCost.toLocaleString()}
              </div>
              <div style={{color: '#94A3B8', fontSize: '0.875rem'}}>Total Investment</div>
            </div>

            <div style={{
              background: 'rgba(16, 185, 129, 0.1)',
              padding: '1.5rem',
              borderRadius: '16px',
              border: '1px solid rgba(16, 185, 129, 0.3)'
            }}>
              <Zap size={32} color="#10B981" style={{marginBottom: '0.5rem'}} />
              <div style={{fontSize: '2rem', fontWeight: 700, color: '#10B981'}}>
                {totalCO2.toLocaleString()} kg
              </div>
              <div style={{color: '#94A3B8', fontSize: '0.875rem'}}>CO₂ Reduction</div>
            </div>
          </div>
        </div>

        {/* Priority Timeline */}
        <div className="result-card">
          <h3 style={{marginBottom: '1.5rem'}}>Implementation Timeline</h3>

          <div style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '1rem'
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '1rem',
              padding: '1rem',
              background: 'rgba(16, 185, 129, 0.1)',
              borderRadius: '12px',
              borderLeft: '4px solid #10B981'
            }}>
              <div style={{
                width: '40px',
                height: '40px',
                background: '#10B981',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white',
                fontWeight: 700
              }}>1</div>
              <div style={{flex: 1}}>
                <div style={{fontWeight: 600}}>Immediate (This Week)</div>
                <div style={{fontSize: '0.875rem', color: '#94A3B8'}}>
                  Smart Thermostat + HVAC Tune-up • ${recommendations[1].cost + recommendations[2].cost} investment
                </div>
              </div>
              <div style={{textAlign: 'right'}}>
                <div style={{fontWeight: 700, color: '#10B981'}}>
                  ${(recommendations[1].annual_savings + recommendations[2].annual_savings).toLocaleString()}
                </div>
                <div style={{fontSize: '0.75rem', color: '#94A3B8'}}>/year saved</div>
              </div>
            </div>

            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '1rem',
              padding: '1rem',
              background: 'rgba(245, 158, 11, 0.1)',
              borderRadius: '12px',
              borderLeft: '4px solid #F59E0B'
            }}>
              <div style={{
                width: '40px',
                height: '40px',
                background: '#F59E0B',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white',
                fontWeight: 700
              }}>2</div>
              <div style={{flex: 1}}>
                <div style={{fontWeight: 600}}>Short Term (This Month)</div>
                <div style={{fontSize: '0.875rem', color: '#94A3B8'}}>
                  LED Lighting Upgrade • ${recommendations[0].cost} investment
                </div>
              </div>
              <div style={{textAlign: 'right'}}>
                <div style={{fontWeight: 700, color: '#10B981'}}>
                  ${recommendations[0].annual_savings.toLocaleString()}
                </div>
                <div style={{fontSize: '0.75rem', color: '#94A3B8'}}>/year saved</div>
              </div>
            </div>

            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '1rem',
              padding: '1rem',
              background: 'rgba(148, 163, 184, 0.1)',
              borderRadius: '12px',
              borderLeft: '4px solid #64748B'
            }}>
              <div style={{
                width: '40px',
                height: '40px',
                background: '#64748B',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white',
                fontWeight: 700
              }}>3</div>
              <div style={{flex: 1}}>
                <div style={{fontWeight: 600}}>Medium Term (Next Quarter)</div>
                <div style={{fontSize: '0.875rem', color: '#94A3B8'}}>
                  Smart Power Strips + Motion Sensors • ${recommendations[3].cost + recommendations[4].cost} investment
                </div>
              </div>
              <div style={{textAlign: 'right'}}>
                <div style={{fontWeight: 700, color: '#10B981'}}>
                  ${(recommendations[3].annual_savings + recommendations[4].annual_savings).toLocaleString()}
                </div>
                <div style={{fontSize: '0.75rem', color: '#94A3B8'}}>/year saved</div>
              </div>
            </div>
          </div>
        </div>

        {/* Detailed Recommendations */}
        <div style={{marginBottom: '2rem'}}>
          <h3 style={{marginBottom: '1.5rem'}}>Detailed Recommendations</h3>

          {recommendations.map((rec, idx) => (
            <div 
              key={rec.id}
              style={{
                background: 'rgba(30, 41, 59, 0.8)',
                borderRadius: '16px',
                marginBottom: '1rem',
                border: '1px solid',
                borderColor: expandedRec === idx ? 'rgba(16, 185, 129, 0.5)' : 'rgba(16, 185, 129, 0.1)',
                overflow: 'hidden',
                transition: 'all 0.3s'
              }}
            >
              {/* Header */}
              <div 
                onClick={() => setExpandedRec(expandedRec === idx ? -1 : idx)}
                style={{
                  padding: '1.5rem',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '1rem'
                }}
              >
                <div style={{
                  width: '48px',
                  height: '48px',
                  background: 'rgba(16, 185, 129, 0.1)',
                  borderRadius: '12px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: '#10B981'
                }}>
                  <Lightbulb size={24} />
                </div>

                <div style={{flex: 1}}>
                  <div style={{display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.25rem'}}>
                    <h4 style={{margin: 0}}>{rec.title}</h4>
                    <span style={{
                      padding: '0.25rem 0.75rem',
                      borderRadius: '50px',
                      fontSize: '0.75rem',
                      fontWeight: 600,
                      background: rec.priority === 'high' ? 'rgba(16, 185, 129, 0.2)' : 'rgba(245, 158, 11, 0.2)',
                      color: rec.priority === 'high' ? '#10B981' : '#F59E0B'
                    }}>
                      {rec.priority} priority
                    </span>
                    <span style={{
                      padding: '0.25rem 0.75rem',
                      borderRadius: '50px',
                      fontSize: '0.75rem',
                      fontWeight: 600,
                      background: 'rgba(100, 116, 139, 0.2)',
                      color: getDifficultyColor(rec.difficulty)
                    }}>
                      {rec.difficulty}
                    </span>
                  </div>
                  <p style={{margin: 0, color: '#94A3B8', fontSize: '0.875rem'}}>
                    ROI: {rec.roi_years} years • Investment: ${rec.cost} • Savings: ${rec.annual_savings.toLocaleString()}/year
                  </p>
                </div>

                <div style={{textAlign: 'right', marginRight: '1rem'}}>
                  <div style={{fontSize: '1.5rem', fontWeight: 700, color: '#10B981'}}>
                    ${rec.annual_savings.toLocaleString()}
                  </div>
                  <div style={{fontSize: '0.75rem', color: '#94A3B8'}}>annual savings</div>
                </div>

                {expandedRec === idx ? <ChevronUp size={24} color="#94A3B8" /> : <ChevronDown size={24} color="#94A3B8" />}
              </div>

              {/* Expanded Content */}
              {expandedRec === idx && (
                <div style={{
                  padding: '0 1.5rem 1.5rem',
                  borderTop: '1px solid rgba(16, 185, 129, 0.1)'
                }}>
                  <p style={{margin: '1rem 0', lineHeight: 1.6}}>{rec.description}</p>

                  <div style={{margin: '1.5rem 0'}}>
                    <h5 style={{marginBottom: '0.75rem', color: '#10B981'}}>Implementation Steps:</h5>
                    <ol style={{margin: 0, paddingLeft: '1.5rem', color: '#94A3B8'}}>
                      {rec.steps.map((step, stepIdx) => (
                        <li key={stepIdx} style={{marginBottom: '0.5rem'}}>{step}</li>
                      ))}
                    </ol>
                  </div>

                  <div style={{
                    display: 'flex',
                    gap: '1rem',
                    flexWrap: 'wrap',
                    marginTop: '1rem'
                  }}>
                    <div style={{
                      background: 'rgba(16, 185, 129, 0.05)',
                      padding: '1rem',
                      borderRadius: '12px',
                      flex: 1,
                      minWidth: '200px'
                    }}>
                      <div style={{fontSize: '0.875rem', color: '#94A3B8', marginBottom: '0.25rem'}}>Implementation Cost</div>
                      <div style={{fontSize: '1.25rem', fontWeight: 700}}>${rec.cost}</div>
                    </div>

                    <div style={{
                      background: 'rgba(16, 185, 129, 0.05)',
                      padding: '1rem',
                      borderRadius: '12px',
                      flex: 1,
                      minWidth: '200px'
                    }}>
                      <div style={{fontSize: '0.875rem', color: '#94A3B8', marginBottom: '0.25rem'}}>Annual Savings</div>
                      <div style={{fontSize: '1.25rem', fontWeight: 700, color: '#10B981'}}>${rec.annual_savings.toLocaleString()}</div>
                    </div>

                    <div style={{
                      background: 'rgba(16, 185, 129, 0.05)',
                      padding: '1rem',
                      borderRadius: '12px',
                      flex: 1,
                      minWidth: '200px'
                    }}>
                      <div style={{fontSize: '0.875rem', color: '#94A3B8', marginBottom: '0.25rem'}}>CO₂ Reduction</div>
                      <div style={{fontSize: '1.25rem', fontWeight: 700, color: '#10B981'}}>{rec.co2_reduction} kg/year</div>
                    </div>
                  </div>

                  <div style={{marginTop: '1rem'}}>
                    <div style={{fontSize: '0.875rem', color: '#94A3B8', marginBottom: '0.5rem'}}>
                      Recommended Suppliers:
                    </div>
                    <div style={{display: 'flex', gap: '0.5rem', flexWrap: 'wrap'}}>
                      {rec.suppliers.map((supplier, sIdx) => (
                        <span key={sIdx} style={{
                          background: 'rgba(16, 185, 129, 0.1)',
                          padding: '0.5rem 1rem',
                          borderRadius: '8px',
                          fontSize: '0.875rem',
                          color: '#10B981'
                        }}>
                          {supplier}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Next Steps CTA */}
        <div style={{
          background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.1) 0%, rgba(20, 184, 166, 0.1) 100%)',
          borderRadius: '20px',
          padding: '2rem',
          textAlign: 'center',
          border: '1px solid rgba(16, 185, 129, 0.3)'
        }}>
          <h3 style={{marginBottom: '1rem'}}>Ready to Start Saving?</h3>
          <p style={{color: '#94A3B8', marginBottom: '1.5rem', maxWidth: '600px', margin: '0 auto 1.5rem'}}>
            Download your complete action plan or schedule a free consultation with our energy experts 
            to discuss implementation details.
          </p>
          <div style={{display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap'}}>
            <button className="cta-button">
              <Download size={20} />
              Download Full Report
            </button>
            <button style={{
              background: 'transparent',
              border: '1px solid rgba(16, 185, 129, 0.3)',
              color: '#10B981',
              padding: '0.75rem 1.5rem',
              borderRadius: '8px',
              cursor: 'pointer',
              fontWeight: 600
            }}>
              Schedule Free Consultation
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Recommendations;
