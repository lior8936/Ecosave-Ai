
import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { 
  Upload, FileText, Zap, TrendingDown, DollarSign, 
  BarChart3, Loader2, CheckCircle, ArrowRight, Leaf,
  Building2, ChevronDown, AlertCircle
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [analysisComplete, setAnalysisComplete] = useState(false);
  const [businessType, setBusinessType] = useState('general');
  const [billId, setBillId] = useState(null);
  const navigate = useNavigate();

  const businessTypes = [
    { value: 'restaurant', label: 'Restaurant / Food Service', icon: '🍽️' },
    { value: 'retail', label: 'Retail Store', icon: '🛍️' },
    { value: 'office', label: 'Office Space', icon: '🏢' },
    { value: 'warehouse', label: 'Warehouse / Storage', icon: '📦' },
    { value: 'manufacturing', label: 'Manufacturing', icon: '🏭' },
    { value: 'hotel', label: 'Hotel / Hospitality', icon: '🏨' },
    { value: 'general', label: 'Other Business', icon: '🏪' },
  ];

  const onDrop = useCallback(async (acceptedFiles) => {
    const file = acceptedFiles[0];
    if (!file) return;

    setUploading(true);
    setUploadProgress(0);

    // Simulate upload progress
    const progressInterval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 90) {
          clearInterval(progressInterval);
          return 90;
        }
        return prev + 10;
      });
    }, 300);

    // Create form data
    const formData = new FormData();
    formData.append('file', file);
    formData.append('business_type', businessType);

    try {
      // In a real app, this would call the actual API
      // const response = await fetch('/api/analyze-bill', {
      //   method: 'POST',
      //   body: formData,
      // });
      // const data = await response.json();

      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 3000));

      clearInterval(progressInterval);
      setUploadProgress(100);

      // Mock response
      const mockBillId = Math.floor(Math.random() * 1000) + 1;
      setBillId(mockBillId);
      setAnalysisComplete(true);

      // Redirect to results after short delay
      setTimeout(() => {
        navigate(`/results/${mockBillId}`);
      }, 1500);

    } catch (error) {
      console.error('Upload failed:', error);
      alert('Upload failed. Please try again.');
      setUploading(false);
    }
  }, [businessType, navigate]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'image/*': ['.png', '.jpg', '.jpeg']
    },
    maxFiles: 1,
    disabled: uploading
  });

  return (
    <div className="dashboard">
      <div className="bg-animation"></div>

      {/* Header */}
      <nav className="navbar">
        <div className="logo">
          <div className="logo-icon">
            <Leaf size={24} color="white" />
          </div>
          EcoSave AI
        </div>
        <div style={{color: '#94A3B8'}}>
          Business Energy Intelligence
        </div>
      </nav>

      <div style={{padding: '8rem 5% 2rem', maxWidth: '800px', margin: '0 auto'}}>
        {/* Page Title */}
        <div style={{textAlign: 'center', marginBottom: '3rem'}}>
          <h1 style={{fontSize: '2.5rem', marginBottom: '1rem'}}>
            Analyze Your Energy Bill
          </h1>
          <p style={{color: '#94A3B8', fontSize: '1.125rem'}}>
            Upload your electricity bill and discover savings opportunities in seconds
          </p>
        </div>

        {/* Business Type Selector */}
        <div style={{marginBottom: '2rem'}}>
          <label style={{
            display: 'block',
            marginBottom: '0.75rem',
            color: '#94A3B8',
            fontSize: '0.875rem',
            fontWeight: 500
          }}>
            Select Your Business Type
          </label>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '0.75rem'
          }}>
            {businessTypes.map((type) => (
              <button
                key={type.value}
                onClick={() => setBusinessType(type.value)}
                style={{
                  padding: '1rem',
                  borderRadius: '12px',
                  border: '1px solid',
                  borderColor: businessType === type.value ? '#10B981' : 'rgba(16, 185, 129, 0.2)',
                  background: businessType === type.value ? 'rgba(16, 185, 129, 0.1)' : 'rgba(30, 41, 59, 0.8)',
                  color: businessType === type.value ? '#10B981' : '#94A3B8',
                  cursor: 'pointer',
                  transition: 'all 0.3s',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.75rem',
                  fontSize: '0.95rem'
                }}
              >
                <span style={{fontSize: '1.25rem'}}>{type.icon}</span>
                {type.label}
              </button>
            ))}
          </div>
        </div>

        {/* Upload Zone */}
        <div
          {...getRootProps()}
          className={`upload-zone ${isDragActive ? 'active' : ''}`}
          style={{
            pointerEvents: uploading ? 'none' : 'auto',
            opacity: uploading ? 0.7 : 1
          }}
        >
          <input {...getInputProps()} />

          {!uploading && !analysisComplete && (
            <>
              <div className="upload-icon">
                <Upload size={32} color="white" />
              </div>
              <h3 style={{fontSize: '1.5rem', marginBottom: '0.75rem'}}>
                {isDragActive ? 'Drop your bill here' : 'Drag & drop your electricity bill'}
              </h3>
              <p style={{color: '#94A3B8', marginBottom: '1.5rem'}}>
                or click to browse files (PDF, PNG, JPG)
              </p>
              <div style={{
                display: 'flex',
                gap: '1rem',
                justifyContent: 'center',
                fontSize: '0.875rem',
                color: '#64748B'
              }}>
                <span style={{display: 'flex', alignItems: 'center', gap: '0.5rem'}}>
                  <CheckCircle size={16} color="#10B981" />
                  Free analysis
                </span>
                <span style={{display: 'flex', alignItems: 'center', gap: '0.5rem'}}>
                  <CheckCircle size={16} color="#10B981" />
                  Takes 2 minutes
                </span>
                <span style={{display: 'flex', alignItems: 'center', gap: '0.5rem'}}>
                  <CheckCircle size={16} color="#10B981" />
                  Bank-level secure
                </span>
              </div>
            </>
          )}

          {uploading && (
            <div style={{textAlign: 'center'}}>
              <div className="loading-spinner"></div>
              <h3 style={{marginTop: '1.5rem', marginBottom: '0.75rem'}}>
                Analyzing your bill...
              </h3>
              <p style={{color: '#94A3B8', marginBottom: '1.5rem'}}>
                Our AI is extracting data and calculating savings opportunities
              </p>

              {/* Progress Bar */}
              <div style={{maxWidth: '300px', margin: '0 auto'}}>
                <div className="progress-bar">
                  <div 
                    className="progress-fill" 
                    style={{width: `${uploadProgress}%`}}
                  ></div>
                </div>
                <p style={{fontSize: '0.875rem', color: '#64748B', marginTop: '0.5rem'}}>
                  {uploadProgress}%
                </p>
              </div>

              {/* Analysis Steps */}
              <div style={{
                marginTop: '2rem',
                display: 'flex',
                flexDirection: 'column',
                gap: '0.75rem',
                maxWidth: '300px',
                margin: '2rem auto 0'
              }}>
                {[
                  { label: 'Extracting bill data', done: uploadProgress > 30 },
                  { label: 'Analyzing usage patterns', done: uploadProgress > 60 },
                  { label: 'Comparing with benchmarks', done: uploadProgress > 80 },
                  { label: 'Generating recommendations', done: uploadProgress >= 100 },
                ].map((step, idx) => (
                  <div key={idx} style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.75rem',
                    color: step.done ? '#10B981' : '#64748B',
                    fontSize: '0.875rem'
                  }}>
                    {step.done ? (
                      <CheckCircle size={16} />
                    ) : (
                      <Loader2 size={16} className="animate-spin" />
                    )}
                    {step.label}
                  </div>
                ))}
              </div>
            </div>
          )}

          {analysisComplete && (
            <div style={{textAlign: 'center'}}>
              <div style={{
                width: '80px',
                height: '80px',
                background: 'linear-gradient(135deg, #10B981 0%, #14B8A6 100%)',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 1.5rem',
                boxShadow: '0 0 30px rgba(16, 185, 129, 0.4)',
                animation: 'scaleIn 0.5s ease'
              }}>
                <CheckCircle size={40} color="white" />
              </div>
              <h3 style={{fontSize: '1.5rem', marginBottom: '0.75rem', color: '#10B981'}}>
                Analysis Complete!
              </h3>
              <p style={{color: '#94A3B8'}}>
                Redirecting to your personalized results...
              </p>
            </div>
          )}
        </div>

        {/* Info Cards */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
          gap: '1.5rem',
          marginTop: '3rem'
        }}>
          <div style={{
            background: 'rgba(30, 41, 59, 0.8)',
            borderRadius: '16px',
            padding: '1.5rem',
            border: '1px solid rgba(16, 185, 129, 0.1)'
          }}>
            <div style={{
              width: '40px',
              height: '40px',
              background: 'rgba(16, 185, 129, 0.1)',
              borderRadius: '10px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#10B981',
              marginBottom: '1rem'
            }}>
              <Shield size={20} />
            </div>
            <h4 style={{marginBottom: '0.5rem'}}>Secure & Private</h4>
            <p style={{color: '#94A3B8', fontSize: '0.875rem'}}>
              Your bill data is encrypted and never stored permanently. We only use it to generate your analysis.
            </p>
          </div>

          <div style={{
            background: 'rgba(30, 41, 59, 0.8)',
            borderRadius: '16px',
            padding: '1.5rem',
            border: '1px solid rgba(16, 185, 129, 0.1)'
          }}>
            <div style={{
              width: '40px',
              height: '40px',
              background: 'rgba(16, 185, 129, 0.1)',
              borderRadius: '10px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#10B981',
              marginBottom: '1rem'
            }}>
              <Zap size={20} />
            </div>
            <h4 style={{marginBottom: '0.5rem'}}>AI-Powered Insights</h4>
            <p style={{color: '#94A3B8', fontSize: '0.875rem'}}>
              Our machine learning models analyze millions of data points to find the best savings opportunities.
            </p>
          </div>

          <div style={{
            background: 'rgba(30, 41, 59, 0.8)',
            borderRadius: '16px',
            padding: '1.5rem',
            border: '1px solid rgba(16, 185, 129, 0.1)'
          }}>
            <div style={{
              width: '40px',
              height: '40px',
              background: 'rgba(16, 185, 129, 0.1)',
              borderRadius: '10px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#10B981',
              marginBottom: '1rem'
            }}>
              <DollarSign size={20} />
            </div>
            <h4 style={{marginBottom: '0.5rem'}}>Real Savings</h4>
            <p style={{color: '#94A3B8', fontSize: '0.875rem'}}>
              Average customer saves $3,200 annually. Our recommendations pay for themselves within months.
            </p>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes scaleIn {
          from { transform: scale(0); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }
        .animate-spin {
          animation: spin 1s linear infinite;
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

export default Dashboard;
