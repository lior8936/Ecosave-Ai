
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { 
  Upload, Zap, Leaf, TrendingDown, DollarSign, 
  BarChart3, CheckCircle, ArrowRight, Sun, Wind,
  Menu, X, ChevronRight, Star, Users, Award
} from 'lucide-react';
import './App.css';

// Components
import LandingPage from './pages/LandingPage';
import Dashboard from './pages/Dashboard';
import AnalysisResults from './pages/AnalysisResults';
import Recommendations from './pages/Recommendations';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/results/:billId" element={<AnalysisResults />} />
          <Route path="/recommendations/:billId" element={<Recommendations />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
