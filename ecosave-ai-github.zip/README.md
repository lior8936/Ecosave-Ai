
# 🌱 EcoSave AI - MVP

**AI-powered energy audit platform for small businesses**

EcoSave AI helps small businesses reduce their energy costs by 30% through automated bill analysis and personalized AI recommendations.

![EcoSave AI](https://img.shields.io/badge/EcoSave-AI-green)
![FastAPI](https://img.shields.io/badge/FastAPI-009688?style=flat&logo=fastapi&logoColor=white)
![React](https://img.shields.io/badge/React-61DAFB?style=flat&logo=react&logoColor=black)
![License](https://img.shields.io/badge/license-MIT-blue)

---

## 🚀 מה זה EcoSave AI?

**הבעיה:** עסקים קטנים מבזבזים 20-30% מהאנרגיה שלהם, אבל לא יכולים להרשות ייעוץ אנרגיה מקצועי ($2,000-5,000).

**הפתרון:** מערכת SaaS שמבצעת ביקורת אנרגיה אוטונומית בעזרת AI תמורת $49/חודש.

### תכונות עיקריות:
- ✅ העלאת חשבונית חשמל (PDF/תמונה) וניתוח אוטומטי
- ✅ חילוץ נתונים ב-OCR ו-AI
- ✅ השוואה לבenchmarks בתעשייה
- ✅ המלצות מותאמות אישית עם חישוב ROI
- ✅ תוכנית יישום שלב-אחר-שלב
- ✅ מעקב אחר חיסכון ב-CO2

---

## 🛠️ טכנולוגיות

### Backend:
- **FastAPI** - Framework מהיר ל-API
- **SQLAlchemy** - ORL למסד נתונים
- **Tesseract OCR** - זיהוי תווים בחשבוניות
- **OpenAI API** - ניתוח חכם והמלצות

### Frontend:
- **React 18** - UI Library
- **React Router** - ניתוב
- **React Dropzone** - העלאת קבצים
- **Lucide React** - אייקונים
- **CSS3** - עיצוב מודרני (ירוק-טכנולוגי)

---

## 📁 מבנה הפרויקט

```
ecosave-ai/
├── backend/
│   ├── main.py                 # FastAPI אפליקציה ראשית
│   ├── requirements.txt        # תלויות Python
│   └── app/
│       └── services/
│           ├── bill_analyzer.py      # ניתוח חשבוניות OCR
│           ├── energy_calculator.py  # חישובי יעילות
│           └── ai_recommendations.py   # מנוע המלצות AI
├── frontend/
│   ├── package.json            # תלויות Node.js
│   ├── src/
│   │   ├── App.js              # ראוטר ראשי
│   │   ├── App.css             # עיצוב גלובלי
│   │   └── pages/
│   │       ├── LandingPage.js        # דף נחיתה
│   │       ├── Dashboard.js          # מערכת העלאה
│   │       ├── AnalysisResults.js    # תוצאות ניתוח
│   │       └── Recommendations.js     # המלצות מפורטות
└── README.md
```

---

## 🚀 התקנה והרצה

### דרישות מקדימות:
- Python 3.8+
- Node.js 16+
- Tesseract OCR (להתקנה מקומית)

### 1. Clone והתקנת Backend:

```bash
# Clone repository
git clone https://github.com/yourusername/ecosave-ai.git
cd ecosave-ai/backend

# יצירת virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# או: venv\Scripts\activate  # Windows

# התקנת תלויות
pip install -r requirements.txt

# התקנת Tesseract (Mac)
brew install tesseract
# או Ubuntu:
# sudo apt-get install tesseract-ocr

# הרצת השרת
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### 2. התקנת Frontend:

```bash
cd ../frontend

# התקנת תלויות
npm install

# הרצת אפליקציה
npm start
```

### 3. גישה לאפליקציה:
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000
- API Docs: http://localhost:8000/docs

---

## 💼 מודל עסקי

### מקורות הכנסה:
1. **מנוי בסיסי** - $49/חודש (דוח חודשי + המלצות)
2. **מנוי פרו** - $99/חודש (ניטור בזמן אמת + אוטומציה)
3. **עמלת ספקים** - 5-10% מעסקאות עם ספקי פתרונות
4. **דוחות ESG** - $199/דוח ללקוחות תאגידיים

### תחזית פיננסית:
- **שנה 1:** 100 לקוחות → $4,900 MRR
- **שנה 2:** 500 לקוחות → $24,500 MRR
- **שנה 3:** 2,000 לקוחות → $98,000 MRR

---

## 🎯 אסטרטגיית שיווק

### שלב 1: בניית קהילה (חודש 1-2)
- קבוצת פייסבוק: "בעלי עסקים חכמים - חיסכון באנרגיה"
- תוכן יומי: טיפים לחיסכון באנרגיה
- לייבים עם מומחי אנרגיה

### שלב 2: Lead Generation (חודש 3-4)
- כלי חינם: "מחשבון חיסכון באנרגיה"
- Webinars: "איך לחסוך $500 בחשמל"
- מיילים אוטומטיים

### שלב 3: המרה (חודש 5-6)
- הצעה: "3 חודשים ראשונים ב-$1"
- ערבות החזר כספי
- תוכנית שותפים

---

## 🔒 אבטחה ופרטיות

- ✅ הצפנת SSL בכל התקשורת
- ✅ מחיקת חשבוניות אוטומטית לאחר ניתוח
- ✅ עמידה בתקן GDPR
- ✅ אין שיתוף מידע עם צדדים שלישיים

---

## 🌟 יתרונות תחרותיים

| תכונה | EcoSave AI | יועץ אנרגיה מסורתי |
|-------|-----------|-------------------|
| **מחיר** | $49/חודש | $2,000-5,000 לביקורת |
| **זמן** | 2 דקות | 1-2 שבועות |
| **דיוק** | AI + נתונים | סובייקטיבי |
| **עדכניות** | בזמן אמת | שנתי |
| **נגישות** | 24/7 | שעות עבודה |

---

## 📊 מדדי הצלחה (KPIs)

| מדד | יעד 3 חודשים | יעד שנה |
|-----|-------------|---------|
| לקוחות פעילים | 50 | 500 |
| MRR | $2,450 | $24,500 |
| CAC | <$30 | <$25 |
| Churn Rate | <10% | <5% |
| NPS | >50 | >70 |

---

## 🛣️ מפת דרכים

### Q1 2025 (MVP):
- ✅ ניתוח חשבוניות בסיסי
- ✅ המלצות AI
- ✅ דשבורד פשוט

### Q2 2025:
- ניטור בזמן אמת (IoT integration)
- אפליקציית מובייל
- מערכת שותפים

### Q3 2025:
- אוטומציה מלאה
- חיבור לספקי חשמל
- שוק בינלאומי

---

## 🤝 תרומה לפרויקט

נשמח לתרומות! דרכים לעזור:
1. **דיווח באגים** - פתחו Issue
2. **פיתוח תכונות** - Pull Request
3. **תרגומים** - הוספת שפות
4. **בדיקות משתמשים** - משוב על UX

---

## 📞 צור קשר

- **אתר:** https://ecosave-ai.com
- **אימייל:** hello@ecosave-ai.com
- **טוויטר:** @EcoSaveAI
- **לינקדאין:** EcoSave AI

---

## 📄 רישיון

MIT License - ראו LICENSE לפרטים.

---

**בuilt with 💚 and AI for a greener planet**
