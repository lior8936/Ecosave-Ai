
from typing import Dict, Any, List
import json
import random

class AIRecommendations:
    """
    AI-powered recommendation engine for energy savings
    """

    RECOMMENDATION_DB = {
        'lighting': {
            'title': 'Upgrade to LED Lighting',
            'description': 'Replace incandescent and fluorescent bulbs with LED. LEDs use 75% less energy and last 25x longer.',
            'implementation': 'Start with high-usage areas. ROI typically within 6-12 months.',
            'difficulty': 'easy',
            'cost_estimate': 500,
            'savings_percent': 15,
            'category': 'lighting'
        },
        'smart_thermostat': {
            'title': 'Install Smart Thermostat',
            'description': 'Smart thermostats learn your schedule and adjust temperature automatically, reducing waste when business is closed.',
            'implementation': 'Install programmable thermostat. Set schedules for business hours.',
            'difficulty': 'easy',
            'cost_estimate': 250,
            'savings_percent': 10,
            'category': 'hvac'
        },
        'hvac_maintenance': {
            'title': 'HVAC System Tune-up',
            'description': 'Regular maintenance improves efficiency by up to 15%. Clean filters, check ducts, optimize settings.',
            'implementation': 'Schedule quarterly maintenance. Replace filters monthly.',
            'difficulty': 'easy',
            'cost_estimate': 300,
            'savings_percent': 12,
            'category': 'hvac'
        },
        'energy_audit': {
            'title': 'Professional Energy Audit',
            'description': 'Detailed assessment identifies specific waste areas in your facility.',
            'implementation': 'Hire certified energy auditor. Implement top 3 recommendations.',
            'difficulty': 'medium',
            'cost_estimate': 800,
            'savings_percent': 20,
            'category': 'audit'
        },
        'solar_panels': {
            'title': 'Install Solar Panels',
            'description': 'Generate your own electricity. Tax incentives available. Payback period 5-7 years.',
            'implementation': 'Get quotes from 3 installers. Check federal and state incentives.',
            'difficulty': 'hard',
            'cost_estimate': 15000,
            'savings_percent': 40,
            'category': 'renewable'
        },
        'smart_power_strips': {
            'title': 'Smart Power Strips',
            'description': 'Eliminate phantom loads from equipment on standby. Automatically cut power when not in use.',
            'implementation': 'Install on workstations and equipment areas.',
            'difficulty': 'easy',
            'cost_estimate': 150,
            'savings_percent': 5,
            'category': 'equipment'
        },
        'insulation': {
            'title': 'Improve Insulation',
            'description': 'Better insulation reduces heating and cooling costs significantly.',
            'implementation': 'Seal windows and doors. Add insulation to attic/walls.',
            'difficulty': 'medium',
            'cost_estimate': 2000,
            'savings_percent': 15,
            'category': 'building'
        },
        'motion_sensors': {
            'title': 'Motion Sensor Lighting',
            'description': 'Lights automatically turn off in unoccupied areas like storage rooms, bathrooms.',
            'implementation': 'Install occupancy sensors in low-traffic areas.',
            'difficulty': 'easy',
            'cost_estimate': 400,
            'savings_percent': 8,
            'category': 'lighting'
        },
        'energy_star': {
            'title': 'Upgrade to ENERGY STAR Equipment',
            'description': 'Replace old refrigerators, computers, and equipment with ENERGY STAR certified models.',
            'implementation': 'Replace equipment as they age. Prioritize high-usage items.',
            'difficulty': 'medium',
            'cost_estimate': 3000,
            'savings_percent': 18,
            'category': 'equipment'
        },
        'demand_response': {
            'title': 'Join Demand Response Program',
            'description': 'Utility pays you to reduce usage during peak hours. No cost to participate.',
            'implementation': 'Contact your utility company. Install smart meter if needed.',
            'difficulty': 'easy',
            'cost_estimate': 0,
            'savings_percent': 8,
            'category': 'programs'
        }
    }

    async def generate(self, bill_data: Dict, energy_metrics: Dict, business_type: str) -> List[Dict]:
        """
        Generate personalized recommendations based on bill analysis
        """
        recommendations = []

        # Calculate monthly and annual costs
        monthly_cost = bill_data.get('total_amount', 0)
        annual_cost = monthly_cost * 12

        # Select relevant recommendations based on business type and efficiency score
        selected_keys = self._select_recommendations(business_type, energy_metrics)

        for key in selected_keys:
            rec = self.RECOMMENDATION_DB[key].copy()

            # Calculate personalized savings
            savings_percent = rec['savings_percent']
            annual_savings = (annual_cost * savings_percent) / 100

            # Adjust for difficulty and business size
            cost = rec['cost_estimate']
            if business_type in ['restaurant', 'manufacturing']:
                cost *= 1.5  # Larger operations need more investment
                annual_savings *= 1.5

            # Calculate ROI
            roi_years = cost / annual_savings if annual_savings > 0 else 99
            roi_score = min(100, (annual_savings / cost) * 100) if cost > 0 else 100

            rec['annual_savings'] = round(annual_savings, 2)
            rec['monthly_savings'] = round(annual_savings / 12, 2)
            rec['roi_years'] = round(roi_years, 1)
            rec['roi_score'] = round(roi_score, 0)
            rec['implementation_cost'] = round(cost, 0)
            rec['priority'] = self._calculate_priority(roi_score, rec['difficulty'])
            rec['co2_reduction_kg'] = round((annual_savings / 0.12) * 0.4, 0)  # Approximate CO2 reduction

            recommendations.append(rec)

        # Sort by ROI score
        recommendations.sort(key=lambda x: x['roi_score'], reverse=True)

        return recommendations[:5]  # Return top 5

    def _select_recommendations(self, business_type: str, metrics: Dict) -> List[str]:
        """Select appropriate recommendations based on business profile"""
        efficiency_score = metrics.get('efficiency_score', 50)

        # Base recommendations for everyone
        base = ['smart_thermostat', 'led_lighting', 'smart_power_strips']

        # Add based on efficiency
        if efficiency_score < 60:
            base.extend(['hvac_maintenance', 'energy_audit'])

        if efficiency_score < 40:
            base.extend(['insulation', 'energy_star'])

        # Business-specific additions
        if business_type == 'restaurant':
            base.extend(['energy_star', 'motion_sensors'])
        elif business_type == 'retail':
            base.extend(['motion_sensors', 'demand_response'])
        elif business_type == 'office':
            base.extend(['demand_response', 'energy_star'])

        # Add solar for high consumers
        if metrics.get('kwh_per_sqft', 0) > 5:
            base.append('solar_panels')

        # Remove duplicates and return
        return list(dict.fromkeys(base))

    def _calculate_priority(self, roi_score: float, difficulty: str) -> str:
        """Calculate implementation priority"""
        if roi_score > 200 and difficulty == 'easy':
            return 'high'
        elif roi_score > 100 or difficulty == 'easy':
            return 'medium'
        else:
            return 'low'
