
import re
import pytesseract
from PIL import Image
import pdf2image
import os
from typing import Dict, Any
import json

class BillAnalyzer:
    """
    AI-powered electricity bill analyzer
    Extracts key information from electricity bills using OCR and pattern matching
    """

    def __init__(self):
        self.patterns = {
            'total_amount': [
                r'Total Amount[\s:]*[$]?([\d,]+\.?\d*)',
                r'Amount Due[\s:]*[$]?([\d,]+\.?\d*)',
                r'Bill Total[\s:]*[$]?([\d,]+\.?\d*)',
                r'Payment Due[\s:]*[$]?([\d,]+\.?\d*)',
                r'[\s:]*[$]?([\d,]+\.\d{2})[\s]*(?:Total|Due|Amount)',
            ],
            'kwh_consumed': [
                r'(\d+)\s*kWh',
                r'Usage[\s:]*(\d+)',
                r'Consumption[\s:]*(\d+)',
                r'(\d+)\s*KWH',
                r'Total Usage[\s:]*(\d+)',
            ],
            'billing_period': [
                r'(\w+ \d{1,2},? \d{4})\s*-\s*(\w+ \d{1,2},? \d{4})',
                r'(\d{1,2}/\d{1,2}/\d{2,4})\s*-\s*(\d{1,2}/\d{1,2}/\d{2,4})',
                r'Period[\s:]*(.+?)(?:
|$)',
            ],
            'rate_per_kwh': [
                r'Rate[\s:]*[$]?([\d.]+)\s*/?\s*kWh',
                r'([\d.]+)\s*¢?\s*per\s*kWh',
                r'Price[\s:]*[$]?([\d.]+)',
            ]
        }

    async def extract_data(self, file_path: str) -> Dict[str, Any]:
        """
        Extract data from bill image or PDF
        """
        # Convert PDF to image if needed
        if file_path.lower().endswith('.pdf'):
            images = pdf2image.convert_from_path(file_path)
            text = ""
            for image in images:
                text += pytesseract.image_to_string(image) + "
"
        else:
            image = Image.open(file_path)
            text = pytesseract.image_to_string(image)

        # Extract data using patterns
        extracted = self._extract_with_patterns(text)

        # Add metadata
        extracted['raw_text'] = text[:1000]  # First 1000 chars for debugging
        extracted['extraction_confidence'] = self._calculate_confidence(extracted)

        return extracted

    def _extract_with_patterns(self, text: str) -> Dict[str, Any]:
        """Extract data using regex patterns"""
        result = {}

        for field, patterns in self.patterns.items():
            for pattern in patterns:
                match = re.search(pattern, text, re.IGNORECASE)
                if match:
                    if field == 'billing_period' and len(match.groups()) > 1:
                        result[field] = f"{match.group(1)} - {match.group(2)}"
                    else:
                        value = match.group(1).replace(',', '')
                        try:
                            result[field] = float(value)
                        except:
                            result[field] = value
                    break

        # Calculate derived metrics
        if 'total_amount' in result and 'kwh_consumed' in result:
            result['calculated_rate'] = result['total_amount'] / result['kwh_consumed']

        return result

    def _calculate_confidence(self, extracted: Dict) -> float:
        """Calculate confidence score based on extracted fields"""
        required_fields = ['total_amount', 'kwh_consumed']
        found = sum(1 for field in required_fields if field in extracted)
        return (found / len(required_fields)) * 100
