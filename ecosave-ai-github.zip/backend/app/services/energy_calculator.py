
from typing import Dict, Any
import json

class EnergyCalculator:
    """
    Calculates energy efficiency metrics and benchmarks
    """

    # Industry benchmarks (kWh per sq ft per month)
    INDUSTRY_BENCHMARKS = {
        'restaurant': {'avg': 5.5, 'good': 4.0, 'excellent': 3.0},
        'retail': {'avg': 3.0, 'good': 2.0, 'excellent': 1.5},
        'office': {'avg': 2.5, 'good': 1.8, 'excellent': 1.2},
        'warehouse': {'avg': 1.5, 'good': 1.0, 'excellent': 0.7},
        'manufacturing': {'avg': 8.0, 'good': 6.0, 'excellent': 4.5},
        'general': {'avg': 3.0, 'good': 2.2, 'excellent': 1.6}
    }

    # Average costs per kWh by region (simplified)
    REGIONAL_RATES = {
        'default': 0.12,
        'california': 0.22,
        'texas': 0.11,
        'new_york': 0.18,
        'florida': 0.11
    }

    def calculate_metrics(self, bill_data: Dict[str, Any], business_type: str) -> Dict[str, Any]:
        """
        Calculate comprehensive energy metrics
        """
        kwh = bill_data.get('kwh_consumed', 0)
        total = bill_data.get('total_amount', 0)

        # Basic metrics
        cost_per_kwh = total / kwh if kwh > 0 else 0

        # Estimate square footage (simplified assumption)
        estimated_sqft = self._estimate_square_footage(business_type, kwh)

        # Efficiency metrics
        kwh_per_sqft = kwh / estimated_sqft if estimated_sqft > 0 else 0

        # Compare to industry benchmark
        benchmark = self.INDUSTRY_BENCHMARKS.get(business_type, self.INDUSTRY_BENCHMARKS['general'])

        if kwh_per_sqft <= benchmark['excellent']:
            efficiency_score = 90
            comparison = 'excellent'
        elif kwh_per_sqft <= benchmark['good']:
            efficiency_score = 75
            comparison = 'good'
        elif kwh_per_sqft <= benchmark['avg']:
            efficiency_score = 50
            comparison = 'average'
        else:
            efficiency_score = 30
            comparison = 'below_average'

        # Calculate potential waste
        potential_waste_percent = self._calculate_waste(kwh_per_sqft, benchmark['good'])
        wasted_kwh = kwh * (potential_waste_percent / 100)
        wasted_cost = wasted_kwh * cost_per_kwh

        return {
            'cost_per_kwh': round(cost_per_kwh, 3),
            'estimated_sqft': estimated_sqft,
            'kwh_per_sqft': round(kwh_per_sqft, 2),
            'efficiency_score': efficiency_score,
            'industry_comparison': comparison,
            'benchmark_avg': benchmark['avg'],
            'potential_waste_percent': round(potential_waste_percent, 1),
            'wasted_kwh_monthly': round(wasted_kwh, 0),
            'wasted_cost_monthly': round(wasted_cost, 2),
            'wasted_cost_annual': round(wasted_cost * 12, 2),
            'co2_emissions_monthly_kg': round(kwh * 0.4, 0),  # Approx 0.4 kg CO2 per kWh
            'trees_needed': round((kwh * 0.4 * 12) / 20, 1)  # 20 kg CO2 absorbed per tree annually
        }

    def _estimate_square_footage(self, business_type: str, kwh: float) -> int:
        """Estimate business size based on consumption"""
        estimates = {
            'restaurant': 800,
            'retail': 1200,
            'office': 1500,
            'warehouse': 3000,
            'manufacturing': 2500,
            'general': 1000
        }
        return estimates.get(business_type, 1000)

    def _calculate_waste(self, actual: float, benchmark_good: float) -> float:
        """Calculate percentage of potential waste"""
        if actual <= benchmark_good:
            return 0
        return ((actual - benchmark_good) / actual) * 100
