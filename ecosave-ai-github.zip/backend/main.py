
from fastapi import FastAPI, File, UploadFile, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from datetime import datetime
import os
import shutil
from typing import List, Optional
import json

# ייבוא השירותים שלנו
from app.services.bill_analyzer import BillAnalyzer
from app.services.ai_recommendations import AIRecommendations
from app.services.energy_calculator import EnergyCalculator

# Database setup
SQLALCHEMY_DATABASE_URL = "sqlite:///./ecosave.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Database Models
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    business_name = Column(String)
    business_type = Column(String)  # restaurant, retail, office, etc.
    created_at = Column(DateTime, default=datetime.utcnow)

class Bill(Base):
    __tablename__ = "bills"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer)
    file_path = Column(String)
    upload_date = Column(DateTime, default=datetime.utcnow)
    total_amount = Column(Float)
    kwh_consumed = Column(Float)
    billing_period = Column(String)
    extracted_data = Column(JSON)
    analysis_results = Column(JSON)
    recommendations = Column(JSON)
    potential_savings = Column(Float, default=0.0)

# Create tables
Base.metadata.create_all(bind=engine)

# FastAPI App
app = FastAPI(
    title="EcoSave AI API",
    description="AI-powered energy audit platform for small businesses",
    version="1.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Initialize services
bill_analyzer = BillAnalyzer()
ai_recommendations = AIRecommendations()
energy_calculator = EnergyCalculator()

@app.post("/api/analyze-bill")
async def analyze_bill(
    file: UploadFile = File(...),
    business_type: str = "general",
    db: Session = Depends(get_db)
):
    """
    Upload and analyze an electricity bill
    """
    try:
        # Save uploaded file
        file_location = f"uploads/{file.filename}"
        os.makedirs("uploads", exist_ok=True)

        with open(file_location, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        # Analyze bill using AI
        extracted_data = await bill_analyzer.extract_data(file_location)

        # Calculate energy metrics
        energy_metrics = energy_calculator.calculate_metrics(
            extracted_data, 
            business_type
        )

        # Generate AI recommendations
        recommendations = await ai_recommendations.generate(
            extracted_data,
            energy_metrics,
            business_type
        )

        # Calculate potential savings
        potential_savings = sum([r['annual_savings'] for r in recommendations])

        # Save to database
        db_bill = Bill(
            file_path=file_location,
            total_amount=extracted_data.get('total_amount', 0),
            kwh_consumed=extracted_data.get('kwh_consumed', 0),
            billing_period=extracted_data.get('billing_period', ''),
            extracted_data=extracted_data,
            analysis_results=energy_metrics,
            recommendations=recommendations,
            potential_savings=potential_savings
        )
        db.add(db_bill)
        db.commit()
        db.refresh(db_bill)

        return {
            "success": True,
            "bill_id": db_bill.id,
            "extracted_data": extracted_data,
            "energy_metrics": energy_metrics,
            "recommendations": recommendations,
            "potential_savings": potential_savings,
            "summary": {
                "total_bill": extracted_data.get('total_amount'),
                "kwh_used": extracted_data.get('kwh_consumed'),
                "cost_per_kwh": extracted_data.get('total_amount', 0) / extracted_data.get('kwh_consumed', 1),
                "efficiency_score": energy_metrics.get('efficiency_score', 0),
                "industry_comparison": energy_metrics.get('industry_comparison', 'average')
            }
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/recommendations/{bill_id}")
async def get_recommendations(bill_id: int, db: Session = Depends(get_db)):
    """
    Get detailed recommendations for a specific bill
    """
    bill = db.query(Bill).filter(Bill.id == bill_id).first()
    if not bill:
        raise HTTPException(status_code=404, detail="Bill not found")

    return {
        "recommendations": bill.recommendations,
        "potential_savings": bill.potential_savings,
        "implementation_plan": generate_implementation_plan(bill.recommendations)
    }

def generate_implementation_plan(recommendations):
    """Generate a prioritized implementation plan"""
    sorted_recs = sorted(recommendations, key=lambda x: x['roi_score'], reverse=True)

    plan = {
        "immediate": [r for r in sorted_recs if r['difficulty'] == 'easy'],
        "short_term": [r for r in sorted_recs if r['difficulty'] == 'medium'],
        "long_term": [r for r in sorted_recs if r['difficulty'] == 'hard']
    }

    return plan

@app.get("/api/dashboard/stats")
async def get_dashboard_stats(db: Session = Depends(get_db)):
    """
    Get overall statistics for the dashboard
    """
    total_bills = db.query(Bill).count()
    total_savings = db.query(Bill).with_entities(
        func.sum(Bill.potential_savings)
    ).scalar() or 0

    return {
        "total_bills_analyzed": total_bills,
        "total_potential_savings": round(total_savings, 2),
        "average_savings_per_bill": round(total_savings / total_bills, 2) if total_bills > 0 else 0,
        "co2_saved_kg": round(total_savings * 0.4, 2)  # Approximate CO2 saving
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
